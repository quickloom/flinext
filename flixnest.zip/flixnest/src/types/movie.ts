export interface Movie {
  id: number;
  title: string;
  year: number;
  director: string;
  duration: string;
  genre: string[];
  rating: number;
  description: string;
  poster: string;
  backdrop?: string;
  cast: string[];
  featured?: boolean;
  trending?: boolean;
  popular?: boolean;
  publicDomain: boolean;
  embedUrl?: string;
}

export interface MovieData {
  featured: Movie[];
  movies: Movie[];
  genres: Genre[];
}

export interface Genre {
  name: string;
  description: string;
}
