import { Film } from 'lucide-react';

const LoadingSpinner = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900">
      <div className="relative">
        <Film className="h-16 w-16 text-red-500 animate-spin" />
        <div className="absolute inset-0 h-16 w-16 border-4 border-red-500/20 border-t-red-500 rounded-full animate-spin"></div>
      </div>
      <p className="mt-4 text-gray-400 text-lg">Loading FlixNest...</p>
    </div>
  );
};

export default LoadingSpinner;
