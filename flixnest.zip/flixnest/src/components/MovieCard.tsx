import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, Heart, Star, Clock, Calendar, Film } from 'lucide-react';
import { Movie } from '../types/movie';
import { useWatchlist } from '../hooks/useWatchlist';

interface MovieCardProps {
  movie: Movie;
  size?: 'small' | 'medium' | 'large';
  showDescription?: boolean;
}

const MovieCard: React.FC<MovieCardProps> = ({ 
  movie, 
  size = 'medium', 
  showDescription = false 
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const { isInWatchlist, toggleWatchlist } = useWatchlist();
  const inWatchlist = isInWatchlist(movie.id);

  const sizeClasses = {
    small: 'w-48 h-72',
    medium: 'w-56 h-80',
    large: 'w-64 h-96'
  };

  const handleWatchlistClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWatchlist(movie);
  };

  return (
    <div className="group relative">
      <Link to={`/movie/${movie.id}`} className="block">
        <div className={`${sizeClasses[size]} relative overflow-hidden rounded-lg bg-gray-800 shadow-lg transition-all duration-300 group-hover:scale-105 group-hover:shadow-2xl`}>
          {/* Movie Poster */}
          <div className="relative h-full">
            {!imageError ? (
              <img
                src={movie.poster}
                alt={movie.title}
                className={`w-full h-full object-cover transition-opacity duration-300 ${
                  imageLoaded ? 'opacity-100' : 'opacity-0'
                }`}
                onLoad={() => setImageLoaded(true)}
                onError={() => {
                  setImageError(true);
                  setImageLoaded(true);
                }}
              />
            ) : (
              <div className="flex items-center justify-center h-full bg-gray-800">
                <div className="text-center text-gray-400">
                  <Film className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-sm">{movie.title}</p>
                </div>
              </div>
            )}
            
            {/* Loading placeholder */}
            {!imageLoaded && !imageError && (
              <div className="absolute inset-0 bg-gray-800 animate-pulse flex items-center justify-center">
                <Film className="h-8 w-8 text-gray-600" />
              </div>
            )}

            {/* Overlay */}
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300 flex items-center justify-center">
              <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-center">
                <Play className="h-16 w-16 text-white mx-auto mb-2" fill="currentColor" />
                <p className="text-white font-semibold">Watch Now</p>
              </div>
            </div>

            {/* Rating Badge */}
            <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center space-x-1">
              <Star className="h-3 w-3 text-yellow-400" fill="currentColor" />
              <span className="text-white text-xs font-medium">{movie.rating}</span>
            </div>

            {/* Watchlist Button */}
            <button
              onClick={handleWatchlistClick}
              className="absolute top-2 right-2 p-2 bg-black/70 backdrop-blur-sm rounded-full hover:bg-black/80 transition-colors"
            >
              <Heart
                className={`h-4 w-4 transition-colors ${
                  inWatchlist ? 'text-red-500 fill-red-500' : 'text-white hover:text-red-400'
                }`}
              />
            </button>

            {/* Year Badge */}
            <div className="absolute bottom-2 left-2 bg-red-500/90 backdrop-blur-sm rounded px-2 py-1">
              <span className="text-white text-xs font-medium">{movie.year}</span>
            </div>

            {/* Duration */}
            <div className="absolute bottom-2 right-2 bg-black/70 backdrop-blur-sm rounded px-2 py-1 flex items-center space-x-1">
              <Clock className="h-3 w-3 text-gray-300" />
              <span className="text-white text-xs">{movie.duration}</span>
            </div>
          </div>
        </div>

        {/* Movie Info */}
        <div className="mt-3 px-1">
          <h3 className="text-white font-semibold text-lg leading-tight group-hover:text-red-400 transition-colors">
            {movie.title}
          </h3>
          <div className="flex items-center space-x-2 mt-1 text-sm text-gray-400">
            <Calendar className="h-3 w-3" />
            <span>{movie.year}</span>
            <span>•</span>
            <span>{movie.director}</span>
          </div>
          <div className="flex flex-wrap gap-1 mt-2">
            {movie.genre.slice(0, 2).map((genre) => (
              <span
                key={genre}
                className="px-2 py-1 bg-gray-800 text-gray-300 text-xs rounded-full"
              >
                {genre}
              </span>
            ))}
          </div>
          
          {showDescription && (
            <p className="text-gray-400 text-sm mt-2 line-clamp-3">
              {movie.description}
            </p>
          )}
        </div>
      </Link>
    </div>
  );
};

export default MovieCard;
