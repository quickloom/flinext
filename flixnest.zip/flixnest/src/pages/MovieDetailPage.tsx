import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Heart, Star, Clock, Calendar, User, Film as FilmIcon } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import { Movie, MovieData } from '../types/movie';
import { useWatchlist } from '../hooks/useWatchlist';

const MovieDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [relatedMovies, setRelatedMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [showPlayer, setShowPlayer] = useState(false);
  const { isInWatchlist, toggleWatchlist } = useWatchlist();

  useEffect(() => {
    const fetchMovieData = async () => {
      try {
        const response = await fetch('/data/movies.json');
        const data: MovieData = await response.json();
        const allMovies = [...data.featured, ...data.movies];
        
        const selectedMovie = allMovies.find(m => m.id === parseInt(id || '0'));
        setMovie(selectedMovie || null);

        if (selectedMovie) {
          // Find related movies by genre
          const related = allMovies
            .filter(m => 
              m.id !== selectedMovie.id && 
              m.genre.some(g => selectedMovie.genre.includes(g))
            )
            .slice(0, 6);
          setRelatedMovies(related);
        }
      } catch (error) {
        console.error('Error fetching movie data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovieData();
  }, [id]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-500 mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading movie details...</p>
        </div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <FilmIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Movie Not Found</h2>
          <p className="text-gray-400 mb-6">The movie you're looking for doesn't exist.</p>
          <Link to="/" className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-colors">
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  const inWatchlist = isInWatchlist(movie.id);

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <img
            src={movie.backdrop || movie.poster}
            alt={movie.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
        </div>

        {/* Back Button */}
        <Link
          to="/"
          className="absolute top-8 left-8 z-20 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors"
        >
          <ArrowLeft className="h-6 w-6" />
        </Link>

        {/* Movie Details */}
        <div className="relative z-10 flex items-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-start space-y-8 lg:space-y-0 lg:space-x-12">
            {/* Movie Poster */}
            <div className="flex-shrink-0">
              <img
                src={movie.poster}
                alt={movie.title}
                className="w-80 h-auto rounded-lg shadow-2xl"
              />
            </div>

            {/* Movie Info */}
            <div className="flex-1 max-w-2xl">
              <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
                {movie.title}
              </h1>
              
              <div className="flex flex-wrap items-center gap-4 text-white/80 mb-6">
                <div className="flex items-center space-x-1">
                  <Star className="h-5 w-5 text-yellow-400" fill="currentColor" />
                  <span className="font-semibold text-lg">{movie.rating}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>{movie.year}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>{movie.duration}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <User className="h-4 w-4" />
                  <span>{movie.director}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-6">
                {movie.genre.map((genre) => (
                  <Link
                    key={genre}
                    to={`/genre/${genre.toLowerCase()}`}
                    className="px-3 py-1 bg-red-600/20 border border-red-500/30 text-red-400 rounded-full text-sm hover:bg-red-600/30 transition-colors"
                  >
                    {genre}
                  </Link>
                ))}
              </div>

              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                {movie.description}
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => setShowPlayer(true)}
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors"
                >
                  <Play className="h-5 w-5" fill="currentColor" />
                  <span>Watch Now</span>
                </button>
                <button
                  onClick={() => toggleWatchlist(movie)}
                  className={`px-8 py-4 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors ${
                    inWatchlist
                      ? 'bg-gray-600 hover:bg-gray-500 text-white'
                      : 'bg-gray-800/80 hover:bg-gray-700 text-white backdrop-blur-sm'
                  }`}
                >
                  <Heart className={`h-5 w-5 ${inWatchlist ? 'fill-red-500 text-red-500' : ''}`} />
                  <span>{inWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Video Player Modal */}
      {showPlayer && movie.embedUrl && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-lg max-w-6xl w-full">
            <div className="flex items-center justify-between p-4 border-b border-gray-700">
              <h3 className="text-xl font-semibold text-white">{movie.title}</h3>
              <button
                onClick={() => setShowPlayer(false)}
                className="text-gray-400 hover:text-white text-2xl"
              >
                ×
              </button>
            </div>
            <div className="aspect-video">
              <iframe
                src={movie.embedUrl}
                title={movie.title}
                className="w-full h-full"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      )}

      {/* Movie Details Section */}
      <div className="relative -mt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Cast */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-white mb-6">Cast</h2>
            <div className="flex flex-wrap gap-3">
              {movie.cast.map((actor, index) => (
                <span
                  key={index}
                  className="px-4 py-2 bg-gray-800 text-gray-300 rounded-lg"
                >
                  {actor}
                </span>
              ))}
            </div>
          </section>

          {/* Related Movies */}
          {relatedMovies.length > 0 && (
            <section>
              <h2 className="text-3xl font-bold text-white mb-8">More Like This</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                {relatedMovies.map((relatedMovie) => (
                  <MovieCard key={relatedMovie.id} movie={relatedMovie} size="medium" />
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};

export default MovieDetailPage;
