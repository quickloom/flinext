import { Shield, Eye, Lock, Database, Globe, UserCheck } from 'lucide-react';

const PrivacyPage = () => {
  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Shield className="h-12 w-12 text-green-500" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">Privacy Policy</h1>
          <p className="text-gray-400">
            Last updated: January 1, 2025
          </p>
        </div>

        {/* Introduction */}
        <section className="mb-12">
          <div className="bg-gray-800 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Eye className="h-6 w-6 text-blue-500 mr-3" />
              Our Commitment to Your Privacy
            </h2>
            <p className="text-gray-300 leading-relaxed mb-4">
              At FlixNest, we are committed to protecting your privacy and ensuring 
              transparency about how we collect, use, and protect your information. 
              This Privacy Policy explains our practices regarding your personal data 
              when you use our streaming platform.
            </p>
            <p className="text-gray-300 leading-relaxed">
              We believe in minimal data collection and maximum transparency. This policy 
              describes what information we collect, how we use it, and your rights regarding 
              your personal data.
            </p>
          </div>
        </section>

        {/* Information We Collect */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Database className="h-6 w-6 text-purple-500 mr-3" />
            Information We Collect
          </h2>
          
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Automatically Collected Information</h3>
              <ul className="text-gray-300 space-y-2">
                <li>• IP address and general location information</li>
                <li>• Browser type and version</li>
                <li>• Device information (type, operating system)</li>
                <li>• Pages visited and time spent on our platform</li>
                <li>• Referring website information</li>
              </ul>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Information You Provide</h3>
              <ul className="text-gray-300 space-y-2">
                <li>• Watchlist preferences (stored locally in your browser)</li>
                <li>• Search queries and browsing history on our platform</li>
                <li>• Any feedback or communications you send us</li>
              </ul>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Cookies and Local Storage</h3>
              <p className="text-gray-300 mb-3">
                We use cookies and local storage to enhance your experience:
              </p>
              <ul className="text-gray-300 space-y-2">
                <li>• Essential cookies for basic website functionality</li>
                <li>• Preference cookies to remember your settings</li>
                <li>• Analytics cookies to understand how our site is used</li>
                <li>• Local storage for your watchlist and viewing preferences</li>
              </ul>
            </div>
          </div>
        </section>

        {/* How We Use Information */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <UserCheck className="h-6 w-6 text-green-500 mr-3" />
            How We Use Your Information
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p><strong className="text-white">To Provide Our Service:</strong> We use your information to deliver movie content, maintain your watchlist, and provide search functionality.</p>
              
              <p><strong className="text-white">To Improve Our Platform:</strong> Analytics help us understand user preferences and improve our movie recommendations and site performance.</p>
              
              <p><strong className="text-white">To Ensure Security:</strong> We monitor for security threats and maintain the integrity of our platform.</p>
              
              <p><strong className="text-white">To Comply with Legal Requirements:</strong> We may use information to comply with applicable laws and regulations.</p>
            </div>
          </div>
        </section>

        {/* Data Sharing */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Globe className="h-6 w-6 text-blue-500 mr-3" />
            Information Sharing and Disclosure
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p><strong className="text-white">We Do Not Sell Your Data:</strong> FlixNest does not sell, rent, or trade your personal information to third parties.</p>
              
              <p><strong className="text-white">Service Providers:</strong> We may share information with trusted service providers who help us operate our platform (hosting, analytics, security).</p>
              
              <p><strong className="text-white">Legal Requirements:</strong> We may disclose information if required by law or to protect our rights and users' safety.</p>
              
              <p><strong className="text-white">Business Transfers:</strong> In the event of a merger or acquisition, user information may be transferred as part of the business assets.</p>
            </div>
          </div>
        </section>

        {/* Data Security */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Lock className="h-6 w-6 text-red-500 mr-3" />
            Data Security
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p>We implement appropriate security measures to protect your information:</p>
              <ul className="space-y-2 mt-4">
                <li>• Encrypted data transmission (HTTPS)</li>
                <li>• Secure server infrastructure</li>
                <li>• Regular security audits and updates</li>
                <li>• Limited access to personal information</li>
                <li>• Local storage for sensitive preferences (watchlist)</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Your Rights */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Your Privacy Rights</h2>
          
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Access and Control</h3>
              <p className="text-gray-300">
                You can access and control most of your information directly through our platform. 
                Your watchlist is stored locally and can be managed through your browser.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Cookie Management</h3>
              <p className="text-gray-300">
                You can control cookies through your browser settings. Note that disabling 
                certain cookies may affect the functionality of our platform.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Data Deletion</h3>
              <p className="text-gray-300">
                Since most data is stored locally, you can clear your data by clearing your 
                browser's local storage and cookies for our site.
              </p>
            </div>
          </div>
        </section>

        {/* Third-Party Services */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Third-Party Services</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p><strong className="text-white">Analytics:</strong> We use analytics services to understand how our platform is used and to improve user experience.</p>
              
              <p><strong className="text-white">Content Delivery:</strong> Movie content is served through reputable content delivery networks and archives.</p>
              
              <p><strong className="text-white">External Links:</strong> Our platform may contain links to external sites. We are not responsible for the privacy practices of these sites.</p>
            </div>
          </div>
        </section>

        {/* Children's Privacy */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Children's Privacy</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <p className="text-gray-300 leading-relaxed">
              Our platform is designed for general audiences and contains classic films 
              appropriate for all ages. We do not knowingly collect personal information 
              from children under 13. If we become aware that we have collected such 
              information, we will take steps to delete it promptly.
            </p>
          </div>
        </section>

        {/* Changes to Privacy Policy */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Changes to This Privacy Policy</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <p className="text-gray-300 leading-relaxed">
              We may update this Privacy Policy from time to time. We will notify users 
              of any material changes by posting the new Privacy Policy on this page and 
              updating the "Last updated" date. We encourage you to review this Privacy 
              Policy periodically for any changes.
            </p>
          </div>
        </section>

        {/* Contact */}
        <section>
          <div className="bg-gray-800 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Questions About This Policy?</h2>
            <p className="text-gray-300 mb-6">
              If you have any questions about this Privacy Policy or our privacy practices, 
              please contact us through our platform's feedback system.
            </p>
            <p className="text-sm text-gray-400">
              FlixNest is committed to protecting your privacy and ensuring a safe, 
              enjoyable experience for all users.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default PrivacyPage;
