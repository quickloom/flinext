import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import { Movie, MovieData } from '../types/movie';

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [movieData, setMovieData] = useState<MovieData | null>(null);
  const [searchResults, setSearchResults] = useState<Movie[]>([]);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await fetch('/data/movies.json');
        const data = await response.json();
        setMovieData(data);
      } catch (error) {
        console.error('Error fetching movies:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  useEffect(() => {
    if (!movieData || !searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const allMovies = [...movieData.featured, ...movieData.movies];
    const query = searchQuery.toLowerCase().trim();
    
    let results = allMovies.filter(movie =>
      movie.title.toLowerCase().includes(query) ||
      movie.director.toLowerCase().includes(query) ||
      movie.description.toLowerCase().includes(query) ||
      movie.genre.some(genre => genre.toLowerCase().includes(query)) ||
      movie.cast.some(actor => actor.toLowerCase().includes(query))
    );

    // Filter by genre if selected
    if (selectedGenre !== 'All') {
      results = results.filter(movie => movie.genre.includes(selectedGenre));
    }

    setSearchResults(results);
  }, [movieData, searchQuery, selectedGenre]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery.trim() });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-500 mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  const allGenres = movieData ? ['All', ...movieData.genres.map(genre => genre.name)] : [];

  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Search Movies</h1>
          <p className="text-gray-400">Find your favorite classic films</p>
        </div>

        {/* Search Form */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for movies, directors, actors, genres..."
                className="bg-gray-700 border border-gray-600 rounded-lg pl-10 pr-4 py-3 w-full text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Filter className="h-5 w-5 text-gray-400" />
                  <span className="text-white font-medium">Genre:</span>
                </div>
                <select
                  value={selectedGenre}
                  onChange={(e) => setSelectedGenre(e.target.value)}
                  className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  {allGenres.map(genre => (
                    <option key={genre} value={genre}>{genre}</option>
                  ))}
                </select>
              </div>
              
              <button
                type="submit"
                className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              >
                <Search className="h-4 w-4" />
                <span>Search</span>
              </button>
            </div>
          </form>
        </div>

        {/* Search Results */}
        {searchQuery.trim() ? (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-white mb-2">
                Search Results for "{searchQuery}"
              </h2>
              <p className="text-gray-400">
                Found {searchResults.length} movie{searchResults.length !== 1 ? 's' : ''}
                {selectedGenre !== 'All' && ` in ${selectedGenre}`}
              </p>
            </div>

            {searchResults.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 pb-20">
                {searchResults.map((movie) => (
                  <MovieCard key={movie.id} movie={movie} size="medium" />
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <Search className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No movies found</h3>
                <p className="text-gray-400 mb-6">
                  Try adjusting your search terms or filters
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedGenre('All');
                    setSearchParams({});
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-colors"
                >
                  Clear Search
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-20">
            <Search className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Start Your Search</h3>
            <p className="text-gray-400 mb-6">
              Enter keywords to find movies, directors, actors, or genres
            </p>
            <div className="max-w-md mx-auto">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search movies..."
                    className="bg-gray-700 border border-gray-600 rounded-lg pl-10 pr-4 py-3 w-full text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  />
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Popular Searches */}
        {!searchQuery.trim() && movieData && (
          <div className="mt-16">
            <h3 className="text-xl font-semibold text-white mb-6">Popular Categories</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {movieData.genres.map((genre) => (
                <button
                  key={genre.name}
                  onClick={() => {
                    setSearchQuery(genre.name);
                    setSearchParams({ q: genre.name });
                  }}
                  className="bg-gray-800 hover:bg-gray-700 text-white p-4 rounded-lg transition-colors text-center"
                >
                  <div className="font-semibold">{genre.name}</div>
                  <div className="text-sm text-gray-400 mt-1">{genre.description}</div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPage;
