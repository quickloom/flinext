import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, Play, Grid, List } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import { useWatchlist } from '../hooks/useWatchlist';

const WatchlistPage = () => {
  const { watchlist, clearWatchlist, removeFromWatchlist } = useWatchlist();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'added' | 'title' | 'year' | 'rating'>('added');

  // Sort watchlist based on selected criteria
  const sortedWatchlist = [...watchlist].sort((a, b) => {
    switch (sortBy) {
      case 'title':
        return a.title.localeCompare(b.title);
      case 'year':
        return b.year - a.year; // Newest first
      case 'rating':
        return b.rating - a.rating; // Highest first
      case 'added':
      default:
        return 0; // Keep original order (last added first)
    }
  });

  if (watchlist.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">My Watchlist</h1>
            <p className="text-gray-400">Save movies to watch later</p>
          </div>

          <div className="text-center py-20">
            <Heart className="h-24 w-24 text-gray-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-white mb-4">Your watchlist is empty</h2>
            <p className="text-gray-400 text-lg mb-8 max-w-md mx-auto">
              Start building your collection by adding movies you want to watch later.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors inline-block"
              >
                Discover Movies
              </Link>
              <Link
                to="/browse"
                className="bg-gray-800 hover:bg-gray-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors inline-block"
              >
                Browse All Movies
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">My Watchlist</h1>
            <p className="text-gray-400">
              {watchlist.length} movie{watchlist.length !== 1 ? 's' : ''} saved
            </p>
          </div>
          
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            <button
              onClick={clearWatchlist}
              className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2"
            >
              <Trash2 className="h-4 w-4" />
              <span>Clear All</span>
            </button>
          </div>
        </div>

        {/* Controls */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            {/* Sort Controls */}
            <div className="flex items-center space-x-4">
              <span className="text-white font-medium">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'added' | 'title' | 'year' | 'rating')}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="added">Recently Added</option>
                <option value="title">Title (A-Z)</option>
                <option value="year">Year (Newest First)</option>
                <option value="rating">Rating (Highest First)</option>
              </select>
            </div>

            {/* View Mode */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded transition-colors ${
                  viewMode === 'grid' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Grid className="h-5 w-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded transition-colors ${
                  viewMode === 'list' ? 'bg-red-600 text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                <List className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Watchlist Grid/List */}
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 pb-20">
            {sortedWatchlist.map((movie) => (
              <div key={movie.id} className="relative group">
                <MovieCard movie={movie} size="medium" />
                <button
                  onClick={() => removeFromWatchlist(movie.id)}
                  className="absolute top-2 left-2 bg-red-600/90 hover:bg-red-700 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all z-10"
                  title="Remove from watchlist"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-6 pb-20">
            {sortedWatchlist.map((movie) => (
              <div key={movie.id} className="bg-gray-800 rounded-lg p-6 flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6">
                {/* Movie Poster */}
                <div className="flex-shrink-0">
                  <img
                    src={movie.poster}
                    alt={movie.title}
                    className="w-32 h-48 object-cover rounded-lg"
                  />
                </div>

                {/* Movie Info */}
                <div className="flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">{movie.title}</h3>
                      <div className="flex flex-wrap items-center gap-2 text-gray-400 mb-3">
                        <span>{movie.year}</span>
                        <span>•</span>
                        <span>{movie.duration}</span>
                        <span>•</span>
                        <span>{movie.director}</span>
                        <span>•</span>
                        <div className="flex items-center space-x-1">
                          <span>⭐</span>
                          <span>{movie.rating}</span>
                        </div>
                      </div>
                    </div>
                    
                    <button
                      onClick={() => removeFromWatchlist(movie.id)}
                      className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-lg transition-colors flex-shrink-0"
                      title="Remove from watchlist"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {movie.genre.map((genre) => (
                      <span
                        key={genre}
                        className="px-3 py-1 bg-gray-700 text-gray-300 text-sm rounded-full"
                      >
                        {genre}
                      </span>
                    ))}
                  </div>

                  <p className="text-gray-400 mb-6 line-clamp-3">
                    {movie.description}
                  </p>

                  <div className="flex space-x-4">
                    <Link
                      to={`/movie/${movie.id}`}
                      className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center space-x-2"
                    >
                      <Play className="h-4 w-4" />
                      <span>Watch Now</span>
                    </Link>
                    <Link
                      to={`/movie/${movie.id}`}
                      className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WatchlistPage;
