import { FileText, Scale, Shield, AlertTriangle, CheckCircle, Globe } from 'lucide-react';

const TermsPage = () => {
  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Scale className="h-12 w-12 text-blue-500" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">Terms of Service</h1>
          <p className="text-gray-400">
            Last updated: January 1, 2025
          </p>
        </div>

        {/* Introduction */}
        <section className="mb-12">
          <div className="bg-gray-800 rounded-lg p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <FileText className="h-6 w-6 text-green-500 mr-3" />
              Welcome to FlixNest
            </h2>
            <p className="text-gray-300 leading-relaxed mb-4">
              These Terms of Service ("Terms") govern your use of the FlixNest streaming 
              platform ("Service") operated by FlixNest ("us", "we", or "our"). By accessing 
              or using our Service, you agree to be bound by these Terms.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Please read these Terms carefully before using our Service. If you disagree 
              with any part of these Terms, then you may not access the Service.
            </p>
          </div>
        </section>

        {/* Acceptance of Terms */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <CheckCircle className="h-6 w-6 text-green-500 mr-3" />
            Acceptance of Terms
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p>By accessing and using FlixNest, you acknowledge that you have read, understood, and agree to be bound by these Terms and our Privacy Policy.</p>
              
              <p>These Terms apply to all visitors, users, and others who access or use the Service.</p>
              
              <p>We reserve the right to update these Terms at any time. Changes will be effective immediately upon posting. Your continued use of the Service after any changes constitutes acceptance of the new Terms.</p>
            </div>
          </div>
        </section>

        {/* Description of Service */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Globe className="h-6 w-6 text-blue-500 mr-3" />
            Description of Service
          </h2>
          
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">What FlixNest Offers</h3>
              <ul className="text-gray-300 space-y-2">
                <li>• Free streaming of public domain movies and legally available content</li>
                <li>• Movie search and discovery features</li>
                <li>• Personal watchlist functionality</li>
                <li>• Movie information and metadata</li>
                <li>• Genre-based browsing and filtering</li>
              </ul>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Content Disclaimer</h3>
              <p className="text-gray-300">
                All movies on FlixNest are either in the public domain or available under 
                appropriate licenses. We do not host copyrighted content without proper 
                authorization. All content is sourced from legitimate archives and repositories.
              </p>
            </div>
          </div>
        </section>

        {/* User Responsibilities */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Shield className="h-6 w-6 text-purple-500 mr-3" />
            User Responsibilities
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <h3 className="text-lg font-semibold text-white mb-4">Acceptable Use</h3>
            <div className="space-y-4 text-gray-300">
              <p>You agree to use FlixNest only for lawful purposes and in accordance with these Terms. You agree NOT to:</p>
              
              <ul className="space-y-2 mt-4">
                <li>• Use the Service for any illegal or unauthorized purpose</li>
                <li>• Attempt to gain unauthorized access to our systems</li>
                <li>• Interfere with or disrupt the Service or servers</li>
                <li>• Upload or transmit malicious code or viruses</li>
                <li>• Harvest or collect user information without consent</li>
                <li>• Reproduce, duplicate, or copy content beyond personal use</li>
                <li>• Use automated systems to access the Service</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Content and Copyright */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Content and Intellectual Property</h2>
          
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Public Domain Content</h3>
              <p className="text-gray-300">
                The movies available on FlixNest are in the public domain or available under 
                appropriate licenses. This means they are free to view, share, and use in 
                accordance with their public domain status.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Platform Content</h3>
              <p className="text-gray-300">
                The FlixNest platform, including its design, features, and original content 
                (such as descriptions and metadata), is owned by FlixNest and protected by 
                copyright and other intellectual property laws.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">User-Generated Content</h3>
              <p className="text-gray-300">
                Any content you provide (such as feedback or suggestions) may be used by 
                FlixNest to improve the Service. You retain ownership of your content but 
                grant us a license to use it for platform improvement purposes.
              </p>
            </div>
          </div>
        </section>

        {/* Privacy and Data */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Privacy and Data Protection</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p>Your privacy is important to us. Our collection and use of personal information is governed by our Privacy Policy, which is incorporated into these Terms by reference.</p>
              
              <p>By using FlixNest, you consent to the collection and use of information as described in our Privacy Policy.</p>
              
              <p>We implement appropriate security measures to protect your information, but cannot guarantee absolute security.</p>
            </div>
          </div>
        </section>

        {/* Disclaimers */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <AlertTriangle className="h-6 w-6 text-yellow-500 mr-3" />
            Disclaimers and Limitations
          </h2>
          
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Service Availability</h3>
              <p className="text-gray-300">
                FlixNest is provided "as is" without warranties of any kind. We do not 
                guarantee that the Service will be uninterrupted, secure, or error-free. 
                We reserve the right to modify or discontinue the Service at any time.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Content Accuracy</h3>
              <p className="text-gray-300">
                While we strive to provide accurate information about movies, we cannot 
                guarantee the completeness or accuracy of all content metadata. Movie 
                availability may change without notice.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-3">Limitation of Liability</h3>
              <p className="text-gray-300">
                FlixNest and its operators shall not be liable for any indirect, incidental, 
                special, or consequential damages arising from your use of the Service.
              </p>
            </div>
          </div>
        </section>

        {/* Age Requirements */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Age Requirements</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <p className="text-gray-300 leading-relaxed">
              FlixNest is intended for users of all ages. However, if you are under 13 years 
              of age, you should use this Service only with the involvement and consent of a 
              parent or guardian. We do not knowingly collect personal information from 
              children under 13.
            </p>
          </div>
        </section>

        {/* Termination */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Termination</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p>We may terminate or suspend your access to the Service immediately, without prior notice, for any reason, including breach of these Terms.</p>
              
              <p>You may discontinue use of the Service at any time. Your watchlist and preferences are stored locally and can be cleared through your browser settings.</p>
              
              <p>Upon termination, your right to use the Service will cease immediately.</p>
            </div>
          </div>
        </section>

        {/* Governing Law */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Governing Law</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <p className="text-gray-300 leading-relaxed">
              These Terms shall be governed and construed in accordance with applicable law, 
              without regard to conflict of law provisions. Any disputes arising from these 
              Terms or your use of the Service shall be resolved through appropriate legal 
              channels.
            </p>
          </div>
        </section>

        {/* Changes to Terms */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Changes to Terms</h2>
          
          <div className="bg-gray-800 rounded-lg p-8">
            <div className="space-y-4 text-gray-300">
              <p>We reserve the right to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days notice prior to any new terms taking effect.</p>
              
              <p>What constitutes a material change will be determined at our sole discretion. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.</p>
            </div>
          </div>
        </section>

        {/* Contact Information */}
        <section>
          <div className="bg-gray-800 rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Contact Us</h2>
            <p className="text-gray-300 mb-6">
              If you have any questions about these Terms of Service, please contact us 
              through our platform's feedback system or support channels.
            </p>
            <p className="text-sm text-gray-400">
              Thank you for using FlixNest. We hope you enjoy discovering and watching 
              classic cinema!
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default TermsPage;
