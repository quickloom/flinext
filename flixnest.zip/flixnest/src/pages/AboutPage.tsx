import { Link } from 'react-router-dom';
import { Film, Heart, Shield, Globe, Users, Award } from 'lucide-react';

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <Film className="h-12 w-12 text-red-500" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-red-500 to-red-400 bg-clip-text text-transparent">
              FlixNest
            </h1>
          </div>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Your premier destination for classic cinema and public domain masterpieces
          </p>
        </div>

        {/* Mission Section */}
        <section className="mb-16">
          <div className="bg-gray-800 rounded-lg p-8">
            <h2 className="text-3xl font-bold text-white mb-6 flex items-center">
              <Heart className="h-8 w-8 text-red-500 mr-3" />
              Our Mission
            </h2>
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              FlixNest is dedicated to preserving and sharing the rich heritage of classic cinema. 
              We believe that the greatest films in history should be accessible to everyone, 
              regardless of economic barriers. Our platform exclusively features public domain 
              movies and legally available content, ensuring that these timeless masterpieces 
              continue to inspire and entertain new generations.
            </p>
            <p className="text-gray-300 text-lg leading-relaxed">
              From the pioneering works of Charlie Chaplin and Buster Keaton to the dramatic 
              masterpieces of the silent era, we curate a collection that celebrates the 
              artistry and innovation of early filmmakers who laid the foundation for modern cinema.
            </p>
          </div>
        </section>

        {/* Features Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Why Choose FlixNest?</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gray-800 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Shield className="h-6 w-6 text-green-500 mr-3" />
                <h3 className="text-xl font-semibold text-white">100% Legal Content</h3>
              </div>
              <p className="text-gray-400">
                All movies on our platform are in the public domain or available under 
                Creative Commons licenses. We ensure full compliance with copyright laws.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Globe className="h-6 w-6 text-blue-500 mr-3" />
                <h3 className="text-xl font-semibold text-white">Free Access</h3>
              </div>
              <p className="text-gray-400">
                No subscriptions, no hidden fees. Our entire collection is freely 
                available to movie lovers worldwide.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Award className="h-6 w-6 text-yellow-500 mr-3" />
                <h3 className="text-xl font-semibold text-white">Curated Collection</h3>
              </div>
              <p className="text-gray-400">
                Our team carefully selects and organizes classic films, ensuring 
                high-quality viewing experiences and comprehensive movie information.
              </p>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <div className="flex items-center mb-4">
                <Users className="h-6 w-6 text-purple-500 mr-3" />
                <h3 className="text-xl font-semibold text-white">Community Focused</h3>
              </div>
              <p className="text-gray-400">
                Built for film enthusiasts, by film enthusiasts. We're committed to 
                fostering appreciation for classic cinema.
              </p>
            </div>
          </div>
        </section>

        {/* History Section */}
        <section className="mb-16">
          <div className="bg-gray-800 rounded-lg p-8">
            <h2 className="text-3xl font-bold text-white mb-6">About Public Domain Films</h2>
            <div className="space-y-4 text-gray-300">
              <p>
                Public domain films are movies whose copyrights have expired or were never 
                copyrighted in the first place. In the United States, films published before 
                1929 have entered the public domain, making them freely available for 
                distribution and viewing.
              </p>
              <p>
                These films represent some of the most important works in cinema history, 
                including groundbreaking comedies, dramas, and experimental films that 
                established many of the storytelling techniques still used today.
              </p>
              <p>
                By 2025, a significant number of classic films from 1929 have joined the 
                public domain, expanding the available collection of legally free content 
                that can be shared and preserved for future generations.
              </p>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Our Values</h2>
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-white mb-3">Preservation</h3>
              <p className="text-gray-400">
                We're committed to preserving classic films for future generations by 
                maintaining high-quality digital copies and comprehensive metadata.
              </p>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-white mb-3">Education</h3>
              <p className="text-gray-400">
                Every film includes detailed information about its historical context, 
                cast, crew, and significance in cinema history.
              </p>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-semibold text-white mb-3">Accessibility</h3>
              <p className="text-gray-400">
                We believe great cinema should be accessible to everyone, regardless of 
                their location or economic situation.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="text-center">
          <div className="bg-gray-800 rounded-lg p-8">
            <h2 className="text-3xl font-bold text-white mb-6">Get in Touch</h2>
            <p className="text-gray-400 mb-6">
              Have questions about our collection or suggestions for improvement? 
              We'd love to hear from you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Explore Our Collection
              </Link>
              <Link
                to="/browse"
                className="bg-gray-700 hover:bg-gray-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Browse All Movies
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;
