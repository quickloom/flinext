import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Play, Info, ChevronLeft, ChevronRight, TrendingUp, Star, Clock } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import { Movie, MovieData } from '../types/movie';

const HomePage = () => {
  const [movieData, setMovieData] = useState<MovieData | null>(null);
  const [currentHero, setCurrentHero] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await fetch('/data/movies.json');
        const data = await response.json();
        setMovieData(data);
      } catch (error) {
        console.error('Error fetching movies:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  useEffect(() => {
    if (movieData?.featured.length) {
      const interval = setInterval(() => {
        setCurrentHero((prev) => (prev + 1) % movieData.featured.length);
      }, 8000);
      return () => clearInterval(interval);
    }
  }, [movieData?.featured.length]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-500 mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading movies...</p>
        </div>
      </div>
    );
  }

  if (!movieData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-400">Error loading movies</p>
      </div>
    );
  }

  const featuredMovie = movieData.featured[currentHero];
  const trendingMovies = [...movieData.movies, ...movieData.featured].filter(movie => movie.trending);
  const popularMovies = [...movieData.movies, ...movieData.featured].filter(movie => movie.popular);

  const nextHero = () => {
    setCurrentHero((prev) => (prev + 1) % movieData.featured.length);
  };

  const prevHero = () => {
    setCurrentHero((prev) => (prev - 1 + movieData.featured.length) % movieData.featured.length);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <img
            src={featuredMovie.backdrop || featuredMovie.poster}
            alt={featuredMovie.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 flex items-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 leading-tight">
              {featuredMovie.title}
            </h1>
            <div className="flex items-center space-x-4 text-white/80 mb-6">
              <div className="flex items-center space-x-1">
                <Star className="h-5 w-5 text-yellow-400" fill="currentColor" />
                <span className="font-semibold">{featuredMovie.rating}</span>
              </div>
              <span>•</span>
              <span>{featuredMovie.year}</span>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>{featuredMovie.duration}</span>
              </div>
            </div>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed max-w-xl">
              {featuredMovie.description}
            </p>
            <div className="flex space-x-4">
              <Link
                to={`/movie/${featuredMovie.id}`}
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-semibold flex items-center space-x-2 transition-colors"
              >
                <Play className="h-5 w-5" fill="currentColor" />
                <span>Watch Now</span>
              </Link>
              <Link
                to={`/movie/${featuredMovie.id}`}
                className="bg-gray-800/80 hover:bg-gray-700 text-white px-8 py-4 rounded-lg font-semibold flex items-center space-x-2 transition-colors backdrop-blur-sm"
              >
                <Info className="h-5 w-5" />
                <span>More Info</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Hero Navigation */}
        <button
          onClick={prevHero}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors"
        >
          <ChevronLeft className="h-6 w-6" />
        </button>
        <button
          onClick={nextHero}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors"
        >
          <ChevronRight className="h-6 w-6" />
        </button>

        {/* Hero Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {movieData.featured.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentHero(index)}
              className={`w-3 h-3 rounded-full transition-colors ${
                index === currentHero ? 'bg-red-500' : 'bg-white/30'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content Sections */}
      <div className="relative z-10 -mt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Trending Now */}
          <section className="mb-16">
            <div className="flex items-center space-x-2 mb-8">
              <TrendingUp className="h-6 w-6 text-red-500" />
              <h2 className="text-3xl font-bold text-white">Trending Now</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {trendingMovies.slice(0, 6).map((movie) => (
                <MovieCard key={movie.id} movie={movie} size="medium" />
              ))}
            </div>
          </section>

          {/* Popular Classics */}
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-white">Popular Classics</h2>
              <Link
                to="/browse"
                className="text-red-400 hover:text-red-300 font-semibold transition-colors"
              >
                View All
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {popularMovies.slice(0, 6).map((movie) => (
                <MovieCard key={movie.id} movie={movie} size="medium" />
              ))}
            </div>
          </section>

          {/* All Movies */}
          <section>
            <h2 className="text-3xl font-bold text-white mb-8">Discover More</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {movieData.movies.slice(0, 12).map((movie) => (
                <MovieCard key={movie.id} movie={movie} size="medium" />
              ))}
            </div>
            <div className="text-center mt-12">
              <Link
                to="/browse"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors inline-block"
              >
                Browse All Movies
              </Link>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
