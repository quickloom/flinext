import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Filter } from 'lucide-react';
import MovieCard from '../components/MovieCard';
import { Movie, MovieData, Genre } from '../types/movie';

const GenrePage = () => {
  const { genre } = useParams<{ genre: string }>();
  const [movieData, setMovieData] = useState<MovieData | null>(null);
  const [genreMovies, setGenreMovies] = useState<Movie[]>([]);
  const [genreInfo, setGenreInfo] = useState<Genre | null>(null);
  const [sortBy, setSortBy] = useState<'title' | 'year' | 'rating'>('title');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await fetch('/data/movies.json');
        const data = await response.json();
        setMovieData(data);
      } catch (error) {
        console.error('Error fetching movies:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  useEffect(() => {
    if (!movieData || !genre) return;

    const capitalizedGenre = genre.charAt(0).toUpperCase() + genre.slice(1).toLowerCase();
    const allMovies = [...movieData.featured, ...movieData.movies];
    
    // Find movies in this genre
    const movies = allMovies.filter(movie => 
      movie.genre.some(g => g.toLowerCase() === genre.toLowerCase())
    );
    
    // Find genre info
    const info = movieData.genres.find(g => g.name.toLowerCase() === genre.toLowerCase());
    
    setGenreMovies(movies);
    setGenreInfo(info || { name: capitalizedGenre, description: `Movies in the ${capitalizedGenre} genre` });
  }, [movieData, genre]);

  useEffect(() => {
    // Sort movies based on selected criteria
    const sortedMovies = [...genreMovies].sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.title.localeCompare(b.title);
        case 'year':
          return b.year - a.year; // Newest first
        case 'rating':
          return b.rating - a.rating; // Highest first
        default:
          return 0;
      }
    });
    
    setGenreMovies(sortedMovies);
  }, [sortBy]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-500 mx-auto"></div>
          <p className="mt-4 text-gray-400">Loading movies...</p>
        </div>
      </div>
    );
  }

  if (!genreInfo || genreMovies.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            to="/browse"
            className="inline-flex items-center space-x-2 text-gray-400 hover:text-white mb-8 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Browse</span>
          </Link>
          
          <div className="text-center py-20">
            <h1 className="text-4xl font-bold text-white mb-4">Genre Not Found</h1>
            <p className="text-gray-400 mb-8">
              Sorry, we couldn't find any movies in the "{genre}" genre.
            </p>
            <Link
              to="/browse"
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Browse All Movies
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link
          to="/browse"
          className="inline-flex items-center space-x-2 text-gray-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Browse</span>
        </Link>

        {/* Genre Header */}
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {genreInfo.name} Movies
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl">
            {genreInfo.description}
          </p>
        </div>

        {/* Sort Controls */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-5 w-5 text-gray-400" />
                <span className="text-white font-medium">Sort by:</span>
              </div>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'title' | 'year' | 'rating')}
                className="bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="title">Title (A-Z)</option>
                <option value="year">Year (Newest First)</option>
                <option value="rating">Rating (Highest First)</option>
              </select>
            </div>
            
            <div className="text-gray-400">
              {genreMovies.length} movie{genreMovies.length !== 1 ? 's' : ''} found
            </div>
          </div>
        </div>

        {/* Movies Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 pb-20">
          {genreMovies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} size="medium" />
          ))}
        </div>

        {/* Related Genres */}
        {movieData && (
          <div className="mt-16 pb-20">
            <h2 className="text-2xl font-bold text-white mb-6">Explore Other Genres</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {movieData.genres
                .filter(g => g.name.toLowerCase() !== genre?.toLowerCase())
                .map((genreItem) => (
                  <Link
                    key={genreItem.name}
                    to={`/genre/${genreItem.name.toLowerCase()}`}
                    className="bg-gray-800 hover:bg-gray-700 text-white p-4 rounded-lg transition-colors text-center group"
                  >
                    <div className="font-semibold group-hover:text-red-400 transition-colors">
                      {genreItem.name}
                    </div>
                    <div className="text-sm text-gray-400 mt-1">
                      {genreItem.description}
                    </div>
                  </Link>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GenrePage;
